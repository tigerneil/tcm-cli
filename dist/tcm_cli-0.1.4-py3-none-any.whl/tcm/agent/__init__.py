"""Agent components: planner, executor, synthesizer, session management."""
