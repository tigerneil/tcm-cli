"""tcm-cli: An autonomous agent for Traditional Chinese Medicine research and discovery."""

__version__ = "0.1.1"
