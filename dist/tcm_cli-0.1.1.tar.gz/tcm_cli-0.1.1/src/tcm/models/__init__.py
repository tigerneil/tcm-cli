"""LLM client and model utilities."""
